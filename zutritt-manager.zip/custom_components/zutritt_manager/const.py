DOMAIN = "zutritt_manager"
