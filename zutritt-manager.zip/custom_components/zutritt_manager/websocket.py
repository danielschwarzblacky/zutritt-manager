def async_register_ws(hass): pass
