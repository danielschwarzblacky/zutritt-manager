class ZutrittStorage:
    def __init__(self, hass): self.state = {}
