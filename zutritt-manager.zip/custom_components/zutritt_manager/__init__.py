async def async_setup(hass, config): return True
